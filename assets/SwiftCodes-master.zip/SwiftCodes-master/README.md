# SwiftCodes
Swift Codes or BIC Codes for all the Banks in the world.

All the info is grabbed from public websites.
